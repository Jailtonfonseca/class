$("#loginform p").addClass("input-field");
$("#loginsubmitbtn").addClass("btn btn-primary");