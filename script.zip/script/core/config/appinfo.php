<?php

return [
    'name' => 'QuickAd Classified',
    'url' => 'https://bylancer.com',
    'version' => '1.2',
    'buy_now_url' => 'https://codecanyon.net/item/quickad-classified-ads-php-script/19960675'
];
